//
//  ViewController.swift
//  jsonParsing
//
//  Created by ASWIN GOVINDAN on 16/07/20.
//  Copyright © 2020 ASWIN GOVINDAN. All rights reserved.
//

import UIKit
struct list{
    let rep : Int?
    let userid : Int?
    let usertype : String?
   
    let displayname : String?
    init(ob:NSDictionary)
    {
        rep = ob.value(forKey: "reputation") as? Int
        userid = ob.value(forKey: "user_id") as? Int
        usertype = ob.value(forKey: "user_type")as? String
        displayname = ob.value(forKey: "display_name")as? String
        
        
    }
}

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
           super.viewDidLoad()
        getdata()
           // Do any additional setup after loading the view.
       }
    var stack = [list]()
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return stack.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as? TableViewCell
        let rep = stack[indexPath.row].rep
        cell!.text1.text = String(rep!)
         
        let userid = stack[indexPath.row].userid
        cell!.text2.text = String(userid!)
        
        let usertype = stack[indexPath.row].usertype
        cell!.text3.text = String(usertype!)
        
        let displayname = stack[indexPath.row].displayname
        cell!.text4.text = String(displayname!)

return cell!
           
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    
    func getdata(){
          let url = URL(string:"https://api.stackexchange.com/2.2/answers?order=desc&sort=activity&site=stackoverflow");
          URLSession.shared.dataTask(with: url!) { (data, response, error) in
              do{
                  if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableLeaves) as? NSDictionary{
                      
                      let item = json["items"] as? NSArray
                      let owner = item?.value(forKey: "owner") as? NSArray
                      for i in owner! {
                          self.stack.append(list(ob: (i as? NSDictionary)!))
                      }
                      }
                  DispatchQueue.main.async {
                      self.tableview.reloadData()
                  }
              }
              catch{
                  
}}.resume()
}}
