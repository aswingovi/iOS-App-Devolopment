//
//  ViewController.swift
//  PickerView
//
//  Created by ASWIN GOVINDAN on 02/07/20.
//  Copyright © 2020 ASWIN GOVINDAN. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    @IBOutlet weak var textfild: UITextField!
    @IBOutlet weak var PickerView: UIPickerView!
    var a=["a","b","c","d"]
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return a.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return a[row]    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        textfild.text = "\(a[row])"
    }
    


    

    override func viewDidLoad() {
        super.viewDidLoad()
        PickerView.delegate=self
        PickerView.dataSource=self
        
        // Do any additional setup after loading the view.
    }


}

