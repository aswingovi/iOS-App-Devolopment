//
//  ViewController.swift
//  jsonExample3
//
//  Created by ASWIN GOVINDAN on 17/07/20.
//  Copyright © 2020 ASWIN GOVINDAN. All rights reserved.
//

import UIKit
struct list
{
    let name:String?
    let team:String?
    let firstapppearance:String?
    let image:String?
    
    
    init(ob:NSDictionary)
    {
        name = ob.value(forKey: "name") as? String
        team = ob.value(forKey: "team") as? String
        firstapppearance = ob.value(forKey: "firstappearance") as? String
        image = ob.value(forKey: "imageurl") as? String
    }
}

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var tableview: UITableView!
    var ob = [list]()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ob.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        as? TableViewCell
        
        let name = ob[indexPath.row].name
        cell?.text1.text = String(name!)
        let team = ob[indexPath.row].team
        cell?.text2.text =  String(team!)
        let appearance = ob[indexPath.row].firstapppearance
        
        cell?.text3.text  = String(appearance!)
        let image  = ob[indexPath.row].image
        let url1=URL(string:image!)


        let data = NSData(contentsOf:url1!)


        
        cell?.img.image = UIImage(data:data! as Data)
        
        return cell!
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        getdata()
        // Do any additional setup after loading the view.
    }
    func getdata()
    {
        let url = URL(string: "https://simplifiedcoding.net/demos/marvel/")
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            do
            {
                if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableLeaves) as? NSArray
                {
                    for i in json{
                        self.ob.append(list(ob: ((i as? NSDictionary)!)))
                    }
                }
                DispatchQueue.main.async {
                    self.tableview.reloadData()
                }
            }
            catch{
                
            }
        }.resume()
        
    }


}

