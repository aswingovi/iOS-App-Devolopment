//
//  ViewController.swift
//  Two_Pages_Navigation_Basic
//
//  Created by ASWIN GOVINDAN on 01/07/20.
//  Copyright © 2020 ASWIN GOVINDAN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textField1: UITextField!
    @IBOutlet weak var textField2: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func textField2(_ sender: Any) {
    }
    
    @IBAction func buttonPress(_ sender: Any) {
        let nc = self.storyboard?.instantiateViewController(withIdentifier: "second") as! SecondViewController
        nc.a = textField1.text
        nc.b = textField2.text
        self.navigationController?.pushViewController(nc, animated: true)
        
    }
    
}

