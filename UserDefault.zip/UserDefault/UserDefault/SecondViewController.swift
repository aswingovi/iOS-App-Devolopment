//
//  SecondViewController.swift
//  UserDefault
//
//  Created by ASWIN GOVINDAN on 10/07/20.
//  Copyright © 2020 ASWIN GOVINDAN. All rights reserved.
//

import UIKit
let user = UserDefaults.standard


class SecondViewController: UIViewController {
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func register(_ sender: Any) {
        user.set(email.text, forKey: "email")
        user.set(password.text, forKey: "pass")
            
            self.navigationController?.popViewController(animated: true)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
