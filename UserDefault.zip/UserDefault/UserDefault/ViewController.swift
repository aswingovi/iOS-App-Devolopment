//
//  ViewController.swift
//  UserDefault
//
//  Created by ASWIN GOVINDAN on 10/07/20.
//  Copyright © 2020 ASWIN GOVINDAN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var stremail:String?
    var strpassword:String?
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var email: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func login(_ sender: Any) {
        stremail = (user.value(forKey: "email") as! String)
        strpassword = (user.value(forKey: "pass") as! String)
        let vc1 = self.storyboard?.instantiateViewController(withIdentifier: "third") as? ThirdViewController
        if(stremail == email.text && strpassword == password.text)
        {
            self.navigationController?.pushViewController(vc1!, animated: true)        }
        
    }
    
    @IBAction func gotoRegistrationpage(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "second") as? SecondViewController
        
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}

