//
//  ViewController.swift
//  alert_on_button_click
//
//  Created by ASWIN GOVINDAN on 01/07/20.
//  Copyright © 2020 ASWIN GOVINDAN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func OnButtonPress(_ sender: Any) {
        
        let alert = UIAlertController(title: "Alert", message: "Alert Button Tapped", preferredStyle: .alert)
        present(alert,animated: true,completion: nil)
    }
    

}

