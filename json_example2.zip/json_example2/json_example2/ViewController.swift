//
//  ViewController.swift
//  json_example2
//
//  Created by ASWIN GOVINDAN on 17/07/20.
//  Copyright © 2020 ASWIN GOVINDAN. All rights reserved.
//

import UIKit
struct list{
    let name:String?
    let capital:String?
    let region:String?
    let subregion:String?
    let population:Int?
    init(ob:NSDictionary)
    {
         
        name = ob.value(forKey: "name") as? String
        capital = ob.value(forKey: "capital") as? String
        region = ob.value(forKey: "region") as? String
        subregion = ob.value(forKey: "subregion") as? String
        population = ob.value(forKey: "population") as? Int
        
    }
}

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var ob = [list]()
    @IBOutlet weak var tableview: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ob.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as? TableViewCell
        let name = ob[indexPath.row].name
        cell?.text1.text = String(name!)
        
        let capital = ob[indexPath.row].capital
        cell?.text2.text = String(capital!)
        
        let region = ob[indexPath.row].region
        cell?.text3.text = String(region!)
        
        let subregion = ob[indexPath.row].subregion
        cell?.text4.text = String(subregion!)
        return cell!
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        <#code#>
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        getdata()
        // Do any additional setup after loading the view.
    }
    
    func getdata()
    { let url = URL(string: "https://restcountries.eu/rest/v2/all");
        
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            do{
                if let json = try JSONSerialization.jsonObject(with:data!, options: .mutableLeaves) as? NSArray
                {
                    
                    for i in json{
                        self.ob.append(list(ob: ((i as? NSDictionary)!)))
                        
                    }
                }
                DispatchQueue.main.async {
                    self.tableview.reloadData()
                }
                
            }
            catch{
                
            }
        }.resume()
        
    }


}

